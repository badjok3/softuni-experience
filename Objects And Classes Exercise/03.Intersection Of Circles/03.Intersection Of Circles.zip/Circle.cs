﻿namespace _03.Intersection_Of_Circles
{
   public class Circle
    {
        public double CenterX { get; set; }

        public double CenterY { get; set; }

        public double Radius { get; set; }
    }

}
