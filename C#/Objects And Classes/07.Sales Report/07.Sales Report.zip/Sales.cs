﻿namespace _07.Sales_Report
{
    public class Sales
    {
        public string Town { get; set; }

        public double Sum { get; set; }
    }
}
