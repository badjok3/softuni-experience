﻿namespace _08.Mentor_Group
{
    using System;
    using System.Collections.Generic;

    public class Student
    {
        public string Name { get; set; }

        public List<string> Comment { get; set; }

        public List<DateTime> Attendantces { get; set; }
    }
}
