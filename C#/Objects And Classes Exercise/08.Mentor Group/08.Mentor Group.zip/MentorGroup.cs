﻿namespace _08.Mentor_Group
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Globalization;

    public class MentorGroup
    {
        public static void Main()
        {
            var dates = Console.ReadLine();
            var students = new List<Student>();

            while (dates != "end of dates")
            {
                var currentStudent = new Student();
                var parameters = dates.Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);

                currentStudent.Name = parameters[0];
                if (students.Any(x => x.Name == currentStudent.Name))
                {
                    currentStudent = students.First(x => x.Name == currentStudent.Name);
                    for (int i = 1; i < parameters.Length; i++)
                    {
                        var day = DateTime.ParseExact(parameters[i], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                        currentStudent.Attendantces.Add(day);
                    }
                }

                else
                {
                    currentStudent.Attendantces = new List<DateTime>();
                    for (int i = 1; i < parameters.Length; i++)
                    {
                        var day = DateTime.ParseExact(parameters[i], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                        currentStudent.Attendantces.Add(day);
                    }

                    students.Add(currentStudent);
                }

                dates = Console.ReadLine();
            }

            var comments = Console.ReadLine();
            while (comments != "end of comments")
            {
                var parameters = comments.Split('-');
                var currentStudent = new Student();
                currentStudent.Name = parameters[0];
                if (students.Any(x => x.Name == currentStudent.Name))
                {
                    currentStudent = students.First(n => n.Name == currentStudent.Name);
                    if (currentStudent.Comment == null)
                    {
                        currentStudent.Comment = new List<string>();
                    }

                    for (int i = 1; i < parameters.Length; i++)
                    {
                        currentStudent.Comment.Add(parameters[i]);
                    }
                }


                comments = Console.ReadLine();
            }

            var order = students.OrderBy(x => x.Name);
            foreach (var student in students)
            {
                student.Attendantces.Sort();

                Console.WriteLine(student.Name);
                Console.WriteLine("Comments:");
                if (student.Comment != null)
                {
                    foreach (var comment in student.Comment)
                    {
                        Console.WriteLine($"- {comment}");
                    }
                }

                Console.WriteLine("Dates attended:");
                foreach (var date in student.Attendantces)
                {
                    Console.WriteLine($"-- {date.ToString("dd/MM/yyyy")}");
                }

            }
        }
    }
}
